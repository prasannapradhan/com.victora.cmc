sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.victora.cmc.uix.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  