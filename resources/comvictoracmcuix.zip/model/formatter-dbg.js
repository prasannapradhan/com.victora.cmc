sap.ui.define([], function (JSONModel, Device) {
    "use strict";

    return {
    };

});