sap.ui.define([],function(n,e){"use strict";return{getProductListingBackgroundClass:function(n){if(n=="Active"){return"bg-online"}else{return"bg-offline"}}}});
//# sourceMappingURL=formatter.js.map