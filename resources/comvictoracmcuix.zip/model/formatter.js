sap.ui.define([],function(e,i){"use strict";return{}});
//# sourceMappingURL=formatter.js.map